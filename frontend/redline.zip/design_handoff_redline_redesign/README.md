# Handoff: Redline — full product redesign

A privacy-first, EU-first, lawyer-informed AI contract analyser for private individuals. This handoff bundles **9 hi-fi HTML mockups** covering every user-facing screen, plus the design system and implementation notes a developer needs to recreate them in the existing Next.js + React + i18n codebase.

---

## About the design files

The files in `mockups/` are **design references**, not production code. They are self-contained HTML/CSS/JS prototypes that show:

- intended **look** (typography, colour, spacing, composition)
- intended **behaviour** (hover, click, expand, filter, toggle, tab switching)
- intended **copy and tone** (voice is explicit, plain, legally literate — not marketing-fluffy)

The task is to **recreate these designs in the existing Next.js frontend** (`redline/frontend/src/app/[locale]/...`) using its established patterns:

- React Server Components + `"use client"` where needed
- `next-intl` for copy (i18n keys must stay stable unless explicitly changed)
- the existing Tailwind setup (extend the theme with the tokens below)
- the existing state/data-fetching patterns (React Query, local stores)
- the existing API layer (`/api/analyze`, `/api/compare`, etc. — do not touch)

Do **not** ship the HTML as-is. The HTML is a reference for what to build, in React, in the existing app.

---

## Fidelity

**High-fidelity.** Every screen has final colours, typography, spacing, and interactions. Recreate pixel-perfectly within the constraints of the codebase's component libraries.

Where the design calls for a small interaction (expand/collapse, tab switch, filter chip, toggle) the HTML includes a vanilla JS implementation — port that behaviour, not the script.

---

## Design direction — "The Line"

The product is called **Redline**. We deliberately **do not** use strike-through or redlining as a visual device — that would be both derivative and visually noisy. Instead, the line is used as a **compositional primitive**:

- A single 2px red vertical mark next to the wordmark, as a brand signature
- Hard 1–2px rules under mastheads and section heads (editorial, not decorative)
- Margin rules (the thin vertical indent on Landing/Report) that echo the physical margin of a printed document
- Statute IDs and metadata are rendered in mono type on rules — line as skeleton

The aesthetic is **editorial / legal document, modernised**. Think FT's front-page clarity with a tech product's restraint. Serif display type does the dramatic work; sans handles UI; mono handles identifiers.

---

## Design tokens

Port these into `tailwind.config.ts` as theme extensions.

### Colour

```css
/* Paper — cool off-white */
--paper:      #f5f5f3;   /* page background */
--paper-2:    #ececea;   /* subtle hover, secondary surface */
--paper-3:    #e3e2dd;   /* pressed, expanded row background */
--paper-edge: #cac9c5;   /* hairlines, subtle borders */

/* Ink — neutral cool-black (darkened from original for readability) */
--ink:        #131311;   /* primary text, strong UI */
--ink-2:      #2f2e2b;   /* body copy */
--ink-3:      #4a4944;   /* kickers, meta, secondary UI */
--ink-muted:  #7a7872;   /* tertiary / captions */

/* Accent — single red */
--red:        #c3321b;   /* one accent, used sparingly */
--red-deep:   #9a2513;   /* hover / pressed */
--red-soft:   #f5e4df;   /* highlight background for quoted text */

/* Risk palette */
--ok:         #2d7a4f;   /* low risk / similar / better */
--ok-soft:    #e3efe7;
--warn:       #c08a1f;   /* medium risk */
--warn-soft:  #f4ead0;
--info:       #6b6a66;   /* informational / neutral */
--info-soft:  #e6e6e1;
```

Rules:
- **One red, used sparingly** — kicker accents, the brand mark, risk badges, destructive buttons. Do not tint large surfaces red.
- **No gradients.** No drop shadows except the subtlest shadow on floating docks.
- **No rounded corners** above 2px. Cards are rectangles. Buttons are rectangles. This is deliberate — it reads as serious, document-like.

### Typography

Load via Google Fonts:
```
https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300..700&family=Newsreader:ital,opsz,wght@0,6..72,300..700&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap
```

| Variable | Family | Use |
|---|---|---|
| `--serif` | **Fraunces** | H1–H3, masthead titles, clause titles, numbers in stat blocks. Weight 400. Italic for emphasis. |
| `--reading` | **Newsreader** | Body paragraphs, clause quotes, narrative prose. Long-form reading. Italic for quotes. |
| `--sans` | **Inter** | All UI — buttons, nav, form fields, dense labels. |
| `--mono` | **JetBrains Mono** | IDs, statute codes (`NL_BW_7_653`), meta ribbons, kickers, timestamps. Always uppercase + letter-spaced for kickers. |

Type scale (key sizes used across the mockups):

```
Display H1:      52–76px / Fraunces 400 / lh 1 / letter-spacing -0.8 to -1.6
Masthead H1:     40–44px / Fraunces 400 / lh 1.05 / ls -0.7
Section H2 (sh): 11px   / JetBrains 600 / lh 1 / ls 1.8px / UPPERCASE
Section H3 (hh): 30–36px / Fraunces 400 / lh 1.1 / ls -0.5
Lede / sub:      17–20px / Newsreader 400 / lh 1.5
Body:            14px   / Inter 400 / lh 1.5
Reading body:    15.5–17px / Newsreader 400 / lh 1.55
Meta / kicker:   10–11px / JetBrains 500–600 / ls 1.2–1.8px / UPPERCASE
Mono label:      10–12px / JetBrains 400–600 / ls 0.5–1.3px
```

### Spacing

The mockups use an 8px-ish rhythm loosely (4, 8, 10, 12, 14, 18, 24, 30, 40, 60). Standardise into a Tailwind scale and use it consistently. Common gutters:

- Page max-width: `1200–1600px` depending on density (Report is 1600 wide for the 3-column layout)
- Page padding: `40px` horizontal, generous top padding on mastheads (`32–72px`)
- Section vertical rhythm: `30–60px` between major sections, `18–24px` within

### Borders

- Strong: `1px solid var(--ink)` — under the masthead, around the summary band
- Section: `2px solid var(--ink)` under H1 mastheads
- Subtle: `1px solid var(--paper-edge)` — between list rows, around cards, around form inputs
- Accent: `2px solid var(--red)` — brand mark, left border on vertical rails

### Motion

Minimal. Hover states only. Transitions 150ms ease. No scroll animations, no parallax, no entrance choreography. The aesthetic is "read a newspaper", not "watch a pitch deck".

---

## Screens

All paths below are relative to the existing frontend: `redline/frontend/src/app/[locale]/`.

### 1. `Landing.html` → `page.tsx` (upload state)

- **Purpose**: upload entry point. Also doubles as the product's front page for new visitors.
- **Layout**:
  - Full-width sticky top bar with wordmark + `|` red mark, crumbs (`Upload / History / Report`), `Account` + `Sign in` CTAs
  - Hero: 1.4fr / 1fr split. Left = display type headline with italic red accent, lede paragraph, upload dropzone with "drop a contract" affordance (dashed 1px border, tall min-height `260px`). Right = three-row aside with "Reads from", "Watches for", "Flags against".
  - "How it reads" — numbered 3-step flow (Parse / Structure / Explain) on rules
  - "Three pillars" — grid of three bordered cards (private-first · EU law-first · lawyer-reviewed). **Titles max 2 lines with line-height 1.25 and 28px bottom margin** — this was hand-tuned to avoid collisions.
  - Sample contracts row + FAQ
  - Footer
- **Motif**: horizontal rules emanating from the margin (`.hero-rules`). Opacity 0.14 default, 0.2 in "dense" variant, hidden in "minimal" variant. Already wired as a Tweak.
- **State**:
  - Upload dropzone → accepts PDF/DOCX, shows filename + size → transitions to the **Analysing** state
  - "Sign in" CTA → `Auth.html`
- **Behaviour to port**:
  - Drag-over highlight on dropzone (1px solid `--ink`, subtle `--paper-2` fill)
  - File parse errors show inline below dropzone in `--red`
- **Existing file**: `app/[locale]/page.tsx` already has an upload branch of the state machine. Replace the existing upload view with this layout.

### 2. `Analysing.html` → intermediate state of `page.tsx`

- **Purpose**: pipeline visualisation while the contract is being analysed. Replaces the minimal `AnalysisProgress` component.
- **Layout**:
  - Condensed masthead with filename + size + parse stats
  - Centre: 5-stage pipeline (Parse → Structure → Topic-tag → Analyse → Render), each stage is a column with status dot, progress bar, log lines
  - Right column: live "what we're doing" log in mono, with timestamps
- **State**:
  - Stages advance left-to-right; active stage has `--red` accent
  - Completed stages collapse to a compact ✓ summary
  - On completion → route to `Report.html`
- **Existing code**: `AnalysisProgress.tsx` — replace its internals; keep the props interface.

### 3. `Redaction.html` → `app/[locale]/redact/` route

- **Purpose**: confirm role (reading from which side) + review PII redactions before analysis is sent to the LLM. Critical privacy beat.
- **Layout**:
  - Two-column: contract preview (left, ~60%) with redactions overlaid as black boxes + `§` markers, and a redaction control panel (right, ~40%)
  - Right panel: role picker (Employee / Contractor / Tenant / Customer / Other), list of detected entities with checkboxes (names, IBANs, emails, dates — keep toggle per category), "Send to analysis" CTA at bottom
- **Existing code**: `RolePicker.tsx`, `RedactionPreview.tsx` — compose both into this single view.

### 4. `Report.html` → `ReportView.tsx` + report route

- **Purpose**: the main payoff screen. Long-scroll editorial report of the contract analysis.
- **Layout**:
  - 3-column grid: left rail = clause spine (sticky TOC with colour-coded risk dots), centre = long-form report with masthead, summary band, narrative, risk-sorted clause cards, statute appendix, footer; right rail = chat dock / context panel
  - Clause card: title + kicker, risk chip, quoted text (Newsreader italic, `--red-soft` mark highlights), plain-English explanation, statute citations in mono, expand/collapse for full clause context + "ask about this clause" action
- **Existing code**: `ReportView.tsx`, `ClauseCard.tsx`. Replace both. Keep types stable in `types.ts`.
- **Behaviour**:
  - Spine click → smooth-scroll to clause
  - Clause cards expandable; highlighted text on hover shows source position
  - Chat dock is persistent on desktop; on mobile, it's a bottom sheet

### 5. `Compare.html` → `app/[locale]/compare/page.tsx`

- **Purpose**: compare two contracts side-by-side, topic-aligned.
- **Layout**:
  - Masthead with both contract titles, a split summary band (A in `--ink` accent, B in `--red` accent) showing 4 stats per side + a mini risk-mix stripe
  - Narrative paragraph calling out the headline deltas
  - Filter chips (All · Better in B · Better in A · Missing in B · Similar)
  - Topic-aligned diff table: 6 columns (Topic / A excerpt / Δ verdict / B excerpt / Statutes / Expand arrow)
  - Expanded row shows full quote from both sides in bordered cards
- **Behaviour**:
  - Click a row to expand
  - Filter chips filter visible rows
  - Sticky action bar at bottom with aggregate counts + Save/Export CTAs
- **Existing code**: there is a `compare/` route — restyle and restructure.

### 6. `History.html` → `app/[locale]/history/page.tsx`

- **Purpose**: list of previous analyses (stored locally by default).
- **Layout**:
  - Masthead declaring local-first storage
  - Left sidebar: filter groups (Jurisdiction / Risk / Type / When) with active-state indicator
  - Right: editorial feed — each analysis is a 4-column row (date / title+meta / stat quartet / open arrow). Title in Fraunces, meta in Inter, stats in Fraunces numerals
  - Sticky action bar at bottom: "New analysis", "Compare two", "Export library"
- **Existing code**: there is a `history/` route — replace.

### 7. `Account.html` → `app/[locale]/account/page.tsx`

- **Purpose**: profile, plan, privacy controls, devices, data export/delete.
- **Layout**:
  - Masthead + 2-column (200px left nav / content)
  - Sections in order: Profile (key-value rows), Plan (bordered card with price on the right), Usage (4-column usage grid with mini progress bars), Your data (toggles with inline notes), Devices (sessions), Export & delete (GDPR article 15 + 17, with a `--red`-bordered danger block)
  - Toggles are custom: 42×22 rectangle, slides 20px when on, black/paper contrast
- **Key copy**: every privacy toggle has an inline plain-English note. Keep that — it is a selling point.
- **Existing code**: `app/[locale]/account/page.tsx` exists — replace.

### 8. `Auth.html` → `app/[locale]/auth/page.tsx`

- **Purpose**: sign in / sign up with a prominent "skip this" path.
- **Layout**:
  - Full-viewport 1:1 split
  - Left: wordmark + display-type copy establishing that an account is **optional**
  - Right: tabs (Sign in / Create account), form, password OR passkey OR magic link, then a bordered "Rather not sign up?" escape hatch
- **Behaviour**: tabs swap form via `data-mode` on `<body>`. Port to React state.
- **Note**: the "Continue without an account" CTA must be prominent, not hidden. This is a brand signal.

### 9. `Trust.html` → new route `app/[locale]/trust/page.tsx`

- **Purpose**: the positioning piece. Detailed trust & privacy documentation.
- **Layout**: long-scroll with sticky sub-nav, 7 sections:
  1. Data flow — 5-cell diagram showing which pipeline stages touch a server
  2. Compliance — GDPR / AI Act / ePrivacy / SOC 2 table
  3. Models — two pathways (managed Mistral vs. on-device Llama) with key-value specs
  4. Statute catalog — 3-column NL / DE / EU breakdown
  5. Lawyer panel — named individuals, what they reviewed, when
  6. Hard questions — accordion FAQ in candid tone
  7. Audit & status — uptime, SOC 2, erasure log
- **This is a new route.** Add it.

---

## Global interactions & behaviour

Consistent across screens:

- **Sticky top bar** with brand + crumbs + account CTA. Height `49px`, bottom border `1px solid --ink`.
- **Mastheads** under the bar: 32–72px top padding, top row of uppercase mono meta, H1 in Fraunces, 2px ink bottom border.
- **Sticky action bar** at page bottom for screens with primary actions (Compare, History, Account-destructive). 1px top border, bar background paper.
- **Hover states** for interactive rows: background shifts to `--paper-2`, arrow/cue colour shifts to `--red`.
- **Focus states**: 1px `--ink` border on all inputs, no glow, no box-shadow.
- **No loading spinners** — use skeleton bars or progress strips that match the line aesthetic. The Analysing screen sets the pattern.
- **Error states**: inline, in `--red`, plain-English, with an action.

---

## State management

The existing codebase uses React Query + local Zustand/context stores (check `frontend/src/`). For the redesign, no new state machine is needed beyond the existing upload → analysing → redaction → report pipeline (in `page.tsx`). Specifically:

- **Upload state**: file picked, parsing, error → reuse existing reducer
- **Redaction state**: role picked, redaction toggles → extend existing `RolePicker` state
- **Report state**: which clause is expanded, chat dock open/closed, active filter → local component state, **persist** expanded clause set + active filter to `localStorage` (important — users refresh mid-read)
- **Compare state**: filter chip, expanded row → local state, persist filter to `localStorage`
- **History**: filter state → URL query params (`?juris=NL&risk=high`) so filters are shareable
- **Tweaks panel**: present on Landing only for now — deletable before production shipping (it was a design-review tool)

---

## Backend / API — do not touch

The existing Python backend (`redline/backend/`) and its API surface are **stable**. Do not change:

- request/response shapes of `/api/analyze`, `/api/compare`, `/api/redact-preview`
- the statute catalog JSON format
- the clause ID scheme (used in URLs)
- i18n keys (add new ones, do not rename)

If the redesign needs a new field (e.g. "mean confidence" on the compare summary), add it to the response as an optional field and compute on the client if the backend can't yet.

---

## i18n

Keep existing locale keys. New keys should follow the existing namespace convention (see `frontend/public/locales/en/common.json` for the pattern). Copy for every section in the mockups is already written — lift it verbatim into the locale files.

Note on tone: the copy is deliberately **plain, legally literate, slightly dry**. Do not rewrite it to be friendlier. The voice is part of the brand.

---

## What's **not** in the handoff

- Mobile layouts — the mockups are desktop-first (1200–1600 wide). Mobile is a follow-up; reuse the same tokens and stack columns vertically.
- Print / PDF export styles — the Report needs a print stylesheet; spec is forthcoming.
- Chat flow as a standalone page — currently the chat is docked into Report. A dedicated `/chat` route can come later.
- Icon library — avoid iconography as a rule. The mockups use exactly two symbols (`§` section mark and `—` em-dash). If icons become necessary, pick a single flat-stroke set (Lucide, Phosphor line) and use it at `14px`.
- Dark mode — out of scope. The paper aesthetic is intentional and does not have a dark equivalent.

---

## Files in this handoff

```
design_handoff_redline_redesign/
├── README.md              — this file
└── mockups/
    ├── Landing.html       — upload / front page
    ├── Analysing.html     — pipeline visualisation
    ├── Redaction.html     — role picker + PII redaction preview
    ├── Report.html        — main payoff, long-scroll clause analysis
    ├── Compare.html       — two-contract diff
    ├── History.html       — saved analyses feed
    ├── Account.html       — profile + plan + privacy controls
    ├── Auth.html          — sign in / up / skip
    └── Trust.html         — trust & privacy documentation
```

Open any mockup directly in a browser — they're self-contained (load Google Fonts from CDN, no build step). Cross-links between mockups use relative paths so the flow is explorable end-to-end.

---

## Suggested implementation order

1. **Design tokens** — port colour, type, spacing into Tailwind config. One PR.
2. **Shared chrome** — sticky top bar, masthead component, sticky action bar, section head component. One PR.
3. **Landing + Auth** — front door. One PR.
4. **Report** — the main screen, highest leverage. Separate PR because of scope.
5. **Redaction + Analysing** — the pipeline screens. One PR.
6. **History + Compare** — list & diff screens. One PR.
7. **Account + Trust** — settings & positioning. One PR.

Each PR should ship behind a feature flag (`NEXT_PUBLIC_REDESIGN=1`) so rollout can be gradual and reversible.

---

**Questions?** The designer's intent is documented in the HTML source. Hover any section in the mockups to see class names that map to the documented components above.
